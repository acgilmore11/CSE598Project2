'use strict';
const devicerecordcontract = require('./devicerecordcontract.js');
module.exports.contracts = [devicerecordcontract];
